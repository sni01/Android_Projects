package edu.stevens.cs522.cloudchatapp.factory;

/**
 * Created by nisha0634 on 2/17/15.
 */
public interface IContinue<T> {
    public void kontinue(T value);
}
