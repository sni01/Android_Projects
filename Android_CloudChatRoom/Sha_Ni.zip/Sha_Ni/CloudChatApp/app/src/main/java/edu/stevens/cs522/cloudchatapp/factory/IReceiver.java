package edu.stevens.cs522.cloudchatapp.factory;

import android.os.Bundle;

/**
 * Created by nisha0634 on 3/14/15.
 */
public interface IReceiver {
    public void onReceiveResult(int resultCode, Bundle result);
}
