package edu.stevens.cs522.cloudchatapp.factory;

/**
 * Created by nisha0634 on 4/26/15.
 */
public interface ISetChatRoomListener {
    public void setChatRoom(String chatRoomName);
}
